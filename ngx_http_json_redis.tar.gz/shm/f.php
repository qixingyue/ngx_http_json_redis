<html>
<head>
<title>{{title}} </title> 
<meta charset="utf-8" />
</head> 
<body>

<div style="border-bottom:solid 1px black">
<h1><a href="http://7magic.istrone.com/home">流影部落阁{高速版}</a></h1>
<h3>红莲即将绽放，双星终要汇聚，命运的车轮已经开始，请耐心等待……</h3>
</div>

<div style="border-bottom:solid 1px black">
<h3>{{title}}</h3>
<div>
<pre>
{{content}}
</pre>
</div>
<p><a href="{{src_url}}">SRC URL</a> </p>
<p><a href="http://7magic.istrone.com/home">BACK</a> </p>

</div


<div style="margin-top:20px;">
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_3485916'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s22.cnzz.com/stat.php%3Fid%3D3485916%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script>
Copyright © 2011-2014 by <a href="http://istrone.com">istrone </a> 京ICP备11038298号-1
</div>
</body>
</html>
