#!/bin/sh

php home.php
php json.php
cd shm
sh 	a.sh
